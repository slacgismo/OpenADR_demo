

import boto3
import json

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('openadr-NHEC-dev-dispatches')

# "GET /dispatch/{order_id}"


def handler(event, context):
    try:
        http_method = event['httpMethod']
        if http_method == 'GET':
            order_id = event['pathParameters']['order_id']
            return {
                'statusCode': 200,
                'body': json.dumps({'order_id': order_id})
            }
        elif http_method == 'PUT':
            return {
                'statusCode': 200,
                'body': json.dumps({'devce_id': "put dispatch"})
            }
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }
