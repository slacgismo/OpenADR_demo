import json
import asyncio
import boto3
import json
import time
import os
from enum import Enum
dynamodb = boto3.client('dynamodb')
agents_table_name = os.environ["AGENTS_TABLE_NAME"]


class AgentsTableAttributes(Enum):
    AGENT_ID = 'agent_id'
    RESOURCE_ID = 'resource_id'
    STATUS = 'status'
    VALID_AT = 'valid_at'


"""
list of agents
Get /db/agents?resource_id=<resource_id>&valid_at=<valid_at>, Get a list of agents id
"""


def handler(event, context):
    try:
        http_method = event['httpMethod']
        if http_method == 'GET':
            """
            get one agent
            Get /db/agent/{agent_id}, Get an agent info. If there is already a record for <agent_id>,
            then it returns the previous data entry. Otherwise, return the new data entry.
            """
            # check if agent_id is in path
            if 'agent_id' in event['pathParameters']:
                agent_id = event['pathParameters']['agent_id']
                return get_agent_info_from_dynamodb(agent_id=agent_id, table_name=agents_table_name, dynamodb_client=dynamodb)
            else:
                return {
                    'statusCode': 404,
                    'headers': {'Content-Type': 'application/json'},
                    'body': json.dumps({'message': "agent_id is not in path"})
                }

        elif http_method == 'PUT':

            """
            PUT /db/agent/{agent_id}
            Put an agent record to table
            """
            if 'agent_id' in event['pathParameters']:
                agent_id = event['pathParameters']['agent_id']
                request_body = json.loads(event['body'])
                if 'resource_id' not in request_body or 'status' not in request_body:
                    return {
                        'statusCode': 404,
                        'headers': {'Content-Type': 'application/json'},
                        'body': json.dumps({'message': "resource_id or status is not in body"})
                    }

                resource_id = request_body.get('resource_id', None)
                status = request_body.get('status', None)
                valid_at = int(time.time())

                # save data to dynamodb
                return put_agent_info_to_dynamodb(
                    agent_id=agent_id,
                    resource_id=resource_id,
                    status=status,
                    valid_at=valid_at,
                    table_name=agents_table_name,
                    dynamodb_client=dynamodb

                )

        elif http_method == "DELETE":
            """
            Delete /db/agent/{agent_id}
            Delete an agent record to table
            """
            if 'agent_id' in event['pathParameters']:
                agent_id = event['pathParameters']['agent_id']

                # return {
                #     'statusCode': 200,
                #     'headers': {'Content-Type': 'application/json'},
                #     'body': json.dumps({'message': 'Hello delete from agents Lambda!'})
                # }
                return delete_agent_info_from_dynamodb(agent_id=agent_id, table_name=agents_table_name, dynamodb_client=dynamodb)
            else:
                return {
                    'statusCode': 404,
                    'headers': {'Content-Type': 'application/json'},
                    'body': json.dumps({'message': "agent_id is not in path"})
                }
    except Exception as e:
        return {
            'statusCode': 500,
            'headers': {'Content-Type': 'application/json'},
            'body': json.dumps({'error ': str(e)})
        }


def get_agent_info_from_dynamodb(agent_id: str = None, table_name: str = None, dynamodb_client=None):
    response = dynamodb_client.get_item(
        TableName=table_name,
        Key={
            AgentsTableAttributes.AGENT_ID.value: {'S': agent_id}
        }
    )
    if 'Item' in response:
        return {
            'statusCode': 200,
            'headers': {'Content-Type': 'application/json'},
            'body': json.dumps(response['Item'])
        }
    else:
        return {
            'statusCode': 404,
            'headers': {'Content-Type': 'application/json'},
            'body': json.dumps({'message': 'Agent not found'})
        }


def put_agent_info_to_dynamodb(
        agent_id: str = None,
        resource_id: str = None,
        status: str = None,
        valid_at: int = None,
        table_name: str = None,
        dynamodb_client=None
):
    try:
        dynamodb_client.put_item(
            TableName=table_name,
            Item={
                AgentsTableAttributes.AGENT_ID.value: {'S': agent_id},
                AgentsTableAttributes.RESOURCE_ID.value: {'S': resource_id},
                AgentsTableAttributes.STATUS.value: {'N': status},
                AgentsTableAttributes.VALID_AT.value: {'N': str(valid_at)}
            }
        )
    except Exception as e:
        return {
            'statusCode': 500,
            'headers': {'Content-Type': 'application/json'},
            'body': json.dumps({'error ': str(e)})
        }


def delete_agent_info_from_dynamodb(agent_id: str = None, table_name: str = None, dynamodb_client=None):
    try:
        dynamodb_client.delete_item(
            TableName=table_name,
            Key={
                AgentsTableAttributes.AGENT_ID.value: {'S': agent_id}
            }
        )
        return {
            'statusCode': 200,
            'headers': {'Content-Type': 'application/json'},
            'body': json.dumps({'message': 'Agent deleted'})
        }
    except Exception as e:
        return {
            'statusCode': 500,
            'headers': {'Content-Type': 'application/json'},
            'body': json.dumps({'error ': str(e)})
        }
