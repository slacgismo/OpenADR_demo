import json
import asyncio
import boto3
import json
import time
import os
from enum import Enum
from decimal import Decimal
from boto3.dynamodb.conditions import Key
import uuid
import re
# cmmmon_utils, constants is from shared layer
from common_utils import respond, TESSError, HTTPMethods, guid, handle_delete_item_from_dynamodb_with_hash_key, handle_put_item_to_dynamodb_with_hash_key, handle_get_item_from_dynamodb_with_hash_key, delete_items_from_dynamodb, handle_query_items_from_dynamodb, handle_scan_items_from_dynamodb, match_path, create_items_to_dynamodb, handle_create_item_to_dynamodb

dynamodb_client = boto3.client('dynamodb')

meters_table_name = os.environ.get("METERS_TABLE_NAME", None)
meters_table_resource_id_device_id_gsi = os.environ.get(
    "METERS_TABLE_RESOURCE_ID_DEVICE_ID_GSI", None)
meters_table_meter_status_valid_at_gsi = os.environ.get(
    "METERS_TABLE_METER_STATUS_VALID_AT_GSI", None)

environment_variables_list = []
environment_variables_list.append(meters_table_name)
environment_variables_list.append(meters_table_resource_id_device_id_gsi)
environment_variables_list.append(meters_table_meter_status_valid_at_gsi)


class MetersAttributes(Enum):
    meter_id = 'meter_id'
    device_id = 'device_id'
    resource_id = 'resource_id'
    meter_status = 'meter_status'
    valid_at = 'valid_at'


MetersAttributesTypes = {
    MetersAttributes.meter_id.value: {
        'dynamodb_type': 'S',
        'return_type': 'string'
    },
    MetersAttributes.device_id.value: {
        'dynamodb_type': 'S',
        'return_type': 'string'
    },
    MetersAttributes.resource_id.value: {
        'dynamodb_type': 'S',
        'return_type': 'string'
    },
    MetersAttributes.meter_status.value: {
        'dynamodb_type': 'N',
        'return_type': 'integer'
    },
    MetersAttributes.valid_at.value: {
        'dynamodb_type': 'N',
        'return_type': 'integer'
    },
}


class MetersRouteKeys(Enum):
    meters = "meters"
    meter = "meter"
    meters_query = "meters/query"
    meters_scan = "meters/scan"


def handler(event, context):
    try:
        # check the environment variables
        if None in environment_variables_list:
            raise Exception(
                f"environment variables are not set :{environment_variables_list}")

        # parse the path
        path = event['path']
        if 'path' not in event:
            return respond(err=TESSError("path is missing"))

        if match_path(path=path, route_key=MetersRouteKeys.meters.value):
            return handle_meters_route(event=event, context=context)
        elif match_path(path=path, route_key=MetersRouteKeys.meter.value):
            return handle_meter_route(event=event, context=context)
        elif match_path(path=path, route_key=MetersRouteKeys.meters_query.value):
            return handle_meters_query_route(event=event, context=context)
        elif match_path(path=path, route_key=MetersRouteKeys.meters_scan.value):
            return handle_meters_scan_route(event=event, context=context)
    except Exception as e:
        return respond(err=TESSError(str(e)))
# =================================================================================================
# Meters /db/meters
# =================================================================================================


def handle_meters_route(event, context):
    http_method = event['httpMethod']
    if http_method == HTTPMethods.POST.value:

        if 'body' not in event:
            raise KeyError("body is missing")
        request_body = json.loads(event['body'])

        return create_items_to_dynamodb(
            request_body=request_body,
            dynamodb_client=dynamodb_client,
            table_name=meters_table_name,
            hash_key_name=MetersAttributes.meter_id.name,
            attributesTypeDict=MetersAttributesTypes
        )

    elif http_method == HTTPMethods.DELETE.value:
        if 'body' not in event:
            raise KeyError("body is missing")
        request_body = json.loads(event['body'])
        return delete_items_from_dynamodb(
            request_body=request_body,
            dynamodb_client=dynamodb_client,
            table_name=meters_table_name,
            hash_key_name=MetersAttributes.meter_id.name,
        )
    else:
        raise Exception("http method is not supported")


def handle_meter_route(event, context):
    http_method = event['httpMethod']
    if http_method == HTTPMethods.GET.value:
        if 'meter_id' not in event['pathParameters']:
            raise KeyError("meter_id is missing")
        meter_id = event['pathParameters']['meter_id']
        # ========================= #
        # GET /db/meter/{meter_id}
        # ========================= #
        return handle_get_item_from_dynamodb_with_hash_key(
            hash_key_name=MetersAttributes.meter_id.name,
            hash_key_value=meter_id,
            table_name=meters_table_name,
            attributesTypesDict=MetersAttributesTypes,
            dynamodb_client=dynamodb_client
        )
    elif http_method == HTTPMethods.POST.value:
        if 'body' not in event:
            raise KeyError("body is missing")
        request_body = json.loads(event['body'])
        # ========================= #
        # create a new meter
        # POST  /db/meter/{meter_id}
        # ========================= #
        return handle_create_item_to_dynamodb(
            hash_key_name=MetersAttributes.meter_id.name,
            hash_key_value=str(guid()),
            request_body=request_body,
            table_name=meters_table_name,
            attributeTypeDice=MetersAttributesTypes,
            attributesEnum=MetersAttributes,
            dynamodb_client=dynamodb_client

        )
    elif http_method == HTTPMethods.PUT.value:
        if 'meter_id' not in event['pathParameters']:
            raise KeyError("meter_id is missing")
        meter_id = event['pathParameters']['meter_id']
        if 'body' not in event:
            raise KeyError("body is missing")
        request_body = json.loads(event['body'])

        # ========================= #
        # update an meter
        # PUT  /db/meter/{meter_id}
        # ========================= #

        return handle_put_item_to_dynamodb_with_hash_key(
            hash_key_name=MetersAttributes.meter_id.name,
            hash_key_value=meter_id,
            request_body=request_body,
            table_name=meters_table_name,
            attributesTypeDict=MetersAttributesTypes,
            attributesEnum=MetersAttributes,
            dynamodb_client=dynamodb_client
        )
    elif http_method == HTTPMethods.DELETE.value:
        if 'meter_id' not in event['pathParameters']:
            raise KeyError("meter_id is missing")
        meter_id = event['pathParameters']['meter_id']
        # ========================= #
        # delete an meter
        # DELETE  /db/meter/{meter_id}
        # ========================= #
        return handle_delete_item_from_dynamodb_with_hash_key(
            hash_key_name=MetersAttributes.meter_id.name,
            hash_key_value=meter_id,
            table_name=meters_table_name,
            dynamodb_client=dynamodb_client
        )
    else:
        return respond(err=TESSError("http method is not supported"))


# ========================= #
# query an meter
# GET /db/meter/query
# ========================= #


def handle_meters_query_route(event, context):

    http_method = event['httpMethod']
    if http_method == HTTPMethods.GET.value:
        # get query string parameters from event
        query_string_parameters = event['queryStringParameters']
        if query_string_parameters is None:
            raise KeyError("query string parameters are missing")
        return handle_query_items_from_dynamodb(
            query_string_parameters=query_string_parameters,
            table_name=meters_table_name,
            dynamodb_client=dynamodb_client,
            attributes_types_dict=MetersAttributesTypes,
            environment_variables_list=environment_variables_list,

        )
    else:
        raise Exception(f"unsupported http method {http_method}")

# ========================= #
# scan an meter
# GET /db/meter/scans
# ========================= #


def handle_meters_scan_route(event, context):
    http_method = event['httpMethod']
    if http_method == HTTPMethods.GET.value:
        # get query string parameters from event
        query_string_parameters = event['queryStringParameters']
        if query_string_parameters is None:
            raise KeyError("query string parameters are missing")
        return handle_scan_items_from_dynamodb(
            query_string_parameters=query_string_parameters,
            table_name=meters_table_name,
            dynamodb_client=dynamodb_client,
            attributes_types_dict=MetersAttributesTypes,
        )
    else:
        raise Exception(f"unsupported http method {http_method}")


# Shared layer
# def create_items_to_dynamodb(
#         request_body: dict = None,
#         dynamodb_client: boto3.client = None,
#         table_name: str = None,
#         hash_key_name: str = None,
#         attributesTypeDict: dict = None,
# ):
#     # check if data in request body is valid
#     try:
#         if 'data' not in request_body:
#             raise KeyError("data is missing")
#         json_data = request_body['data']
#         print(f"json_data {json_data}")
#         # convert json data to dynamodb format
#         dynamodb_items, created_items = conver_josn_to_dynamodb_format(
#             hash_key=hash_key_name,
#             items=json_data,
#             attributesType=attributesTypeDict)
#         print(f"dynamodb_items {dynamodb_items}")
#         print(f"created_items {created_items}")
#         # put data to dynamodb
#         response = asyncio.run(write_batch_items_to_dynamodb(
#             chunks=dynamodb_items, table_name=table_name, dynamodb_client=dynamodb_client))

#         return respond(res_data=json.dumps(created_items))
#     except Exception as e:
#         return respond(err=TESSError(str(e)))


# def handle_create_item_to_dynamodb(
#         hash_key_name: str = None,
#         hash_key_value: str = None,
#         request_body: dict = None,
#         table_name: str = None,
#         attributeTypeDice=None,
#         attributesEnum=None,
#         dynamodb_client: boto3.client = None):

#     try:
#         # create a new agent
#         # agent_id = str(guid())
#         item, return_item = create_item(
#             primary_key_name=hash_key_name,
#             primary_key_value=hash_key_value,
#             request_body=request_body,
#             attributeType=attributeTypeDice,
#             attributes=attributesEnum
#         )
#         response = asyncio.run(put_item_to_dynamodb(
#             item=item,
#             table_name=table_name,
#             dynamodb_client=dynamodb_client,
#         ))
#         # created_item_hash_key = {
#         #     hash_key_name: hash_key_value
#         # }
#         return respond(res_data=json.dumps(return_item))
#     except Exception as e:
#         raise Exception(str(e))


# def conver_josn_to_dynamodb_format(
#         hash_key: str = None,
#         timestam_index_name: str = 'valid_at',
#         items: list = None,
#         attributesType: dict = None) -> dict:
#     """
#     Convet json to dynamodb format
#     Create a unique id for each hash key
#     Create a valid_at current timestamp
#     params: hash_key: hash key
#     params: items: list of items
#     params: attributesType: dictionary of attributes and type
#     return: dynamodb_items: list of dynamodb items
#     return: created_hash_keys: list of created hash keys
#     """
#     dynamodb_items = []
#     created_items = []
#     for item in items:
#         dynamodb_item = {}
#         single_item = {}
#         for key, value in attributesType.items():
#             print(key, value['dynamodb_type'])
#             dynamodb_type = value['dynamodb_type']
#             # valid at is the current timestamp
#             if key == timestam_index_name:
#                 item_value = str(int(time.time()))
#                 single_item[timestam_index_name] = item_value
#             # create a unique id for hash key
#             elif key == hash_key:
#                 item_value = str(guid())
#                 # hash_key_item = {hash_key: item_value}
#                 single_item[hash_key] = item_value
#                 # created_items.append(hash_key_item)
#             else:
#                 item_value = item[key]
#                 single_item[key] = item_value
#             dynamodb_item[key] = {dynamodb_type: item_value}

#         created_items.append(single_item)
#         dynamodb_items.append(dynamodb_item)
#     # print(dynamodb_items)
#     return dynamodb_items, created_items


# def create_item(
#         primary_key_name: str,
#         primary_key_value: str,
#         request_body: dict = None,
#         attributeType: dict = None,
#         attributes: Enum = None,
# ):
#     item = {}
#     return_item = {}
#     valid_at = str(int(time.time()))
#     for attribute_name, attribute_info in attributeType.items():
#         if attribute_name == attributes.valid_at.name:
#             item[attribute_name] = {
#                 attribute_info['dynamodb_type']: valid_at
#             }
#             return_item[attribute_name] = valid_at
#         elif attribute_name == primary_key_name:
#             item[attribute_name] = {
#                 attribute_info['dynamodb_type']: primary_key_value
#             }
#             return_item[attribute_name] = primary_key_value
#         else:
#             value = request_body.get(attribute_name, None)
#             if value is None:
#                 raise KeyError(f"{attribute_name} not exist in request body.")
#             item[attribute_name] = {
#                 attribute_info['dynamodb_type']: value
#             }
#             return_item[attribute_name] = value
#     return item, return_item


# def handle_put_item_to_dynamodb_with_hash_key(hash_key_value: str,
#                                               hash_key_name: str,
#                                               request_body: dict,
#                                               table_name: str = None,
#                                               attributesTypeDict: dict = None,
#                                               attributesEnum: Enum = None,
#                                               dynamodb_client: boto3.client = None):

#     try:
#         # check if agent_id exists
#         response = asyncio.run(
#             get_item_from_dynamodb(
#                 id=hash_key_value,
#                 key=hash_key_name,
#                 table_name=table_name,
#                 dynamodb_client=dynamodb_client
#             )
#         )
#         item = response.get('Item', None)
#         if item is None:
#             return respond(err=TESSError(f"{hash_key_name}: {hash_key_value} is not exist, please use post method to create a new"))
#         else:
#             # update item

#             item, return_item = create_item(
#                 primary_key_name=hash_key_name,
#                 primary_key_value=hash_key_value,
#                 request_body=request_body,
#                 attributeType=attributesTypeDict,
#                 attributes=attributesEnum
#             )
#             # if not exist, put data in it
#             response = asyncio.run(put_item_to_dynamodb(
#                 item=item,
#                 table_name=table_name,
#                 dynamodb_client=dynamodb_client,
#             ))

#             return respond(res_message="success")
#     except Exception as e:
#         raise Exception(str(e))


# async def get_item_from_dynamodb(id: str, key: str, table_name: str, dynamodb_client):
#     try:
#         response = await asyncio.to_thread(
#             dynamodb_client.get_item,
#             TableName=table_name,
#             Key={
#                 key: {DynamodbTypes.string.value: id}
#             }
#         )
#         return response
#     except Exception as e:
#         raise Exception(str(e))


# def handle_put_item_to_dynamodb_with_hash_key(hash_key_value: str,
#                                               hash_key_name: str,
#                                               request_body: dict,
#                                               table_name: str = None,
#                                               attributesTypeDict: dict = None,
#                                               attributesEnum: Enum = None,
#                                               dynamodb_client: boto3.client = None):

#     try:
#         # check if agent_id exists
#         response = asyncio.run(
#             get_item_from_dynamodb(
#                 id=hash_key_value,
#                 key=hash_key_name,
#                 table_name=table_name,
#                 dynamodb_client=dynamodb_client
#             )
#         )
#         item = response.get('Item', None)
#         if item is None:
#             return respond(err=TESSError(f"{hash_key_name}: {hash_key_value} is not exist, please use post method to create a new"))
#         else:
#             # update item

#             item, return_item = create_item(
#                 primary_key_name=hash_key_name,
#                 primary_key_value=hash_key_value,
#                 request_body=request_body,
#                 attributeType=attributesTypeDict,
#                 attributes=attributesEnum
#             )
#             # if not exist, put data in it
#             response = asyncio.run(put_item_to_dynamodb(
#                 item=item,
#                 table_name=table_name,
#                 dynamodb_client=dynamodb_client,
#             ))

#             return respond(res_message="success")
#     except Exception as e:
#         raise Exception(str(e))


# class DynamodbTypes(Enum):
#     string = 'S'
#     number = 'N'


# async def put_item_to_dynamodb(item: dict,
#                                table_name: str,
#                                dynamodb_client):
#     try:

#         response = await asyncio.to_thread(dynamodb_client.put_item,
#                                            TableName=table_name,
#                                            Item=item
#                                            )
#         return response

#     except Exception as e:
#         raise Exception(str(e))


# async def write_batch_items_to_dynamodb(chunks: list = None, table_name: str = None, dynamodb_client: boto3.client = None, page_size: int = 25):
#     """
#     params: chunks: list of items
#             example: {'agent_id': {'S': '12321'}, 'resource_id': {
#                 'S': '1'}, 'status': {'N': '1'}, 'valid_at': {'N': '1682444347'}}
#     params: table_name: dynamodb table name
#     params: dynamodb_client: boto3 client
#     params: page_size: number of items per page

#     """
#     try:
#         items = []
#         for chunk in chunks:

#             items.append({'PutRequest': {'Item': chunk}})

#         # Use pagination to write items in batches
#         last_evaluated_key = None
#         while True:
#             # Set the pagination parameters
#             pagination_params = {
#                 'TableName': table_name,
#                 'ReturnConsumedCapacity': 'TOTAL',
#                 'Limit': page_size,
#             }
#             if last_evaluated_key:
#                 pagination_params['ExclusiveStartKey'] = last_evaluated_key

#             # Write items in the current page
#             response = await asyncio.to_thread(dynamodb_client.batch_write_item,
#                                                RequestItems={table_name: items})

#             # Check if there are more pages to write
#             if 'UnprocessedItems' in response and response['UnprocessedItems']:
#                 items = response['UnprocessedItems'][table_name]
#                 last_evaluated_key = response.get('LastEvaluatedKey')
#             else:
#                 break

#         return True
#     except Exception as e:
#         raise Exception(str(e))
