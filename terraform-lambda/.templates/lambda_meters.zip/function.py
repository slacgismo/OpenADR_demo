

import boto3
import json

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('openadr-NHEC-dev-meters')

# "PUT /meter/{device_id}/{meter_id}"


def handler(event, context):
    try:
        http_method = event['httpMethod']
        if http_method == 'GET':

            return {
                'statusCode': 200,
                'body': json.dumps({'get meter': "get meter"})
            }
        elif http_method == 'PUT':
            device_id = event['pathParameters']['device_id']
            meter_id = event['pathParameters']['meter_id']
            return {
                'statusCode': 200,
                'body': json.dumps({'devce_id': device_id, "meter_id": meter_id})
            }
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }


# def get_device(event):
#     device_id = event['pathParameters']['device_id']
#     response = table.get_item(Key={'device_id': device_id})
#     if 'Item' not in response:
#         return {
#             'statusCode': 404,
#             'body': json.dumps({'error': f'Device with ID {device_id} not found'})
#         }
#     else:
#         item = response['Item']
#         device = {
#             'device_id': item['device_id'],
#             'name': item['name'],
#             'type': item['type'],
#             'status': item['status'],
#             'created_at': item['created_at']
#         }
#         return {
#             'statusCode': 200,
#             'body': json.dumps(device)
#         }

# def put_meter(event):
#     device_id = event['pathParameters']['device_id']
#     meter_id = event['pathParameters']['meter_id']
#     item = {'device_id': device_id, 'meter_id': meter_id}
#     response = table.put_item(Item=item)
#     if response['ResponseMetadata']['HTTPStatusCode'] == 200:
#         return {
#             'statusCode': 200,
#             'body': json.dumps({'message': f'Meter {meter_id} for device {device_id} saved'})
#         }
#     else:
#         return {
#             'statusCode': 500,
#             'body': json.dumps({'error': 'Failed to save meter'})
#         }
