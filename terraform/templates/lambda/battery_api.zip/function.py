import boto3
import json
from enum import Enum
dynamodb = boto3.client('dynamodb')
table_name = 'openadr-NHEC-dev-mock-battery'

get_battery_data = {
    "BackupBuffer": "10",
    "BatteryCharging": True,
    "BatteryDischarging": False,
    "Consumption_Avg": 0,
    "Consumption_W": 0,
    "Fac": 60,
    "FlowConsumptionBattery": True,
    "FlowConsumptionGrid": False,
    "FlowConsumptionProduction": False,
    "FlowGridBattery": True,
    "FlowProductionBattery": True,
    "FlowProductionGrid": True,
    "GridFeedIn_W": 196,
    "IsSystemInstalled": 1,
    "OperatingMode": "2",
    "Pac_total_W": -1800,
    "Production_W": 1792,
    "RSOC": 50,
    "RemainingCapacity_W": 5432,
    "SystemStatus": "OnGrid",
    "Timestamp": "2023-02-09 14:50:32",
    "USOC": 50,
    "Uac": 237,
    "Ubat": 54,
}


class DeviceBrand(Enum):
    SONNEN_BATTERY = 'sonnen_battery'
    EGAUGE = 'egauge'
    THEROMSTAT = 'thermostat'
    SOLAR = 'solar'
    WATER_HEATER = 'water_heater'


def handler(event, context):
    try:
        http_method = event['httpMethod']
        if http_method == 'GET':
            serial = event['pathParameters']['serial']
            request_body = json.loads(event['body'])
            if 'device_brand' not in request_body:
                return {
                    'statusCode': 500,
                    'headers': {'Content-Type': 'application/json'},
                    'body': json.dumps({'error ': 'device_brand is missing'})
                }
            device_brand = request_body['device_brand']
            if device_brand.lower() == DeviceBrand.SONNEN_BATTERY.value:
                query_params = event['queryStringParameters']
                if query_params is None:
                    # return all data
                    return {
                        'statusCode': 200,
                        'headers': {'Content-Type': 'application/json'},
                        'body': json.dumps(get_battery_data)
                    }
                else:
                    # control mode
                    if 'enable_manual_mode' in query_params:
                        enable_manual_mode = query_params['enable_manual_mode']
                        return {
                            'statusCode': 200,
                            'status': 0,
                            'headers': {'Content-Type': 'application/json'},
                            'body': json.dumps({'enable_manual_mode': enable_manual_mode})
                        }
                    elif 'manual_mode_control' in query_params:
                        manual_mode_control = query_params['manual_mode_control']
                        return {
                            'statusCode': 200,
                            'ReturnCode': 0,
                            'headers': {'Content-Type': 'application/json'},
                            'body': json.dumps({'manual_mode_control': manual_mode_control})
                        }
                    else:
                        return {
                            'statusCode': 500,
                            'headers': {'Content-Type': 'application/json'},
                            'body': json.dumps({'error ': f'query parameter{query_params} not supported'})
                        }
            else:
                return {
                    'statusCode': 500,
                    'headers': {'Content-Type': 'application/json'},
                    'body': json.dumps({'error ': f'device brand{device_brand} not supported'})
                }
        elif http_method == 'PUT':
            serial = event['pathParameters']['serial']
            request_body = json.loads(event['body'])
            if 'device_brand' not in request_body:
                return {
                    'statusCode': 500,
                    'headers': {'Content-Type': 'application/json'},
                    'body': json.dumps({'error ': 'device_brand is missing'})
                }
            device_brand = request_body['device_brand']
            if device_brand == DeviceBrand.SONNEN_BATTERY.value:
                # control battery

                return {
                    'statusCode': 200,
                    'headers': {'Content-Type': 'application/json'},
                    'body': json.dumps(get_battery_data)
                }
            else:
                return {
                    'statusCode': 500,
                    'headers': {'Content-Type': 'application/json'},
                    'body': json.dumps({'error ': f'device brand{device_brand} not supported'})
                }
    except Exception as e:
        return {
            'statusCode': 500,
            'headers': {'Content-Type': 'application/json'},
            'body': json.dumps({'error ': str(e)})
        }
