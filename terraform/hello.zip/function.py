import json
import boto3

def lambda_handler(event, context):
    http_method = event['httpMethod']

    if http_method == 'GET':
        message = 'GET request received'
    elif http_method == 'POST':
        request_body = json.loads(event['body'])
        message = f'POST request received with body: {request_body}'
    else:
        message = 'Unsupported method'

    response = {
        'statusCode': 200,
        'body': json.dumps({'message': message})
    }

    return response

curl "https://os68i8f5ra.execute-api.us-east-2.amazonaws.com/dev/example-hello?Name=Anton"
